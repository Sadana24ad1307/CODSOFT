"use client"

import { Target, Zap } from "lucide-react"

interface LogoProps {
  size?: "sm" | "md" | "lg"
  showText?: boolean
}

export function Logo({ size = "md", showText = true }: LogoProps) {
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-12 w-12",
    lg: "h-16 w-16",
  }

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-3xl",
  }

  return (
    <div className="flex items-center gap-3">
      <div className="relative">
        <div
          className={`${sizeClasses[size]} bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg`}
        >
          <Target className="h-1/2 w-1/2 text-white" />
        </div>
        <div className="absolute -top-1 -right-1 bg-yellow-400 rounded-full p-1">
          <Zap className="h-3 w-3 text-yellow-800" />
        </div>
      </div>
      {showText && (
        <div className="flex flex-col">
          <h1
            className={`${textSizeClasses[size]} font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent`}
          >
            GuessWise
          </h1>
          <p className="text-xs text-gray-500 -mt-1">Number Guessing Game</p>
        </div>
      )}
    </div>
  )
}
