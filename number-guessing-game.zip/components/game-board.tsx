"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { RefreshCw, Trophy, Target, Zap, TrendingUp } from "lucide-react"
import { Logo } from "./logo"

export default function GameBoard() {
  const [gameId, setGameId] = useState<string>("")
  const [playerId] = useState<string>(() => Math.random().toString(36).substring(7))
  const [userGuess, setUserGuess] = useState<string>("")
  const [attempts, setAttempts] = useState<number>(0)
  const [maxAttempts, setMaxAttempts] = useState<number>(7)
  const [feedback, setFeedback] = useState<string>("")
  const [gameStatus, setGameStatus] = useState<"playing" | "won" | "lost">("playing")
  const [score, setScore] = useState<number>(0)
  const [totalScore, setTotalScore] = useState<number>(0)
  const [stats, setStats] = useState({
    totalGames: 0,
    gamesWon: 0,
    totalScore: 0,
    bestStreak: 0,
    currentStreak: 0,
  })
  const [loading, setLoading] = useState<boolean>(false)

  const startNewGame = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/game", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "start" }),
      })

      const data = await response.json()
      if (data.success) {
        setGameId(data.gameId)
        setUserGuess("")
        setAttempts(0)
        setMaxAttempts(data.maxAttempts)
        setFeedback(data.message)
        setGameStatus("playing")
        setScore(0)
      }
    } catch (error) {
      setFeedback("Error starting game. Please try again.")
    }
    setLoading(false)
  }

  const makeGuess = async () => {
    if (!userGuess.trim() || loading) return

    setLoading(true)
    try {
      const response = await fetch("/api/game", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "guess",
          gameId,
          guess: userGuess,
          playerId,
        }),
      })

      const data = await response.json()
      if (data.success) {
        setFeedback(data.message)
        setAttempts(data.attempts)
        setGameStatus(data.status)
        if (data.gameEnded) {
          setScore(data.score || 0)
          setTotalScore((prev) => prev + (data.score || 0))
          loadStats()
        }
      } else {
        setFeedback(data.message)
      }
    } catch (error) {
      setFeedback("Error making guess. Please try again.")
    }
    setUserGuess("")
    setLoading(false)
  }

  const loadStats = async () => {
    try {
      const response = await fetch("/api/game", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "stats", playerId }),
      })

      const data = await response.json()
      if (data.success) {
        setStats(data.stats)
      }
    } catch (error) {
      console.error("Error loading stats:", error)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && gameStatus === "playing") {
      makeGuess()
    }
  }

  useEffect(() => {
    startNewGame()
    loadStats()
  }, [])

  const winRate = stats.totalGames > 0 ? Math.round((stats.gamesWon / stats.totalGames) * 100) : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Logo size="lg" />
          <p className="text-gray-600 mt-2">Challenge your mind with the ultimate number guessing experience!</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Game Card */}
          <div className="md:col-span-2">
            <Card className="shadow-xl border-0 bg-white/80 backdrop-blur">
              <CardHeader className="text-center">
                <CardTitle className="text-xl font-bold text-gray-800 flex items-center justify-center gap-2">
                  <Target className="h-5 w-5 text-blue-600" />
                  Current Game
                </CardTitle>
                <CardDescription>Guess the number between 1 and 100</CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Current Game Stats */}
                <div className="flex justify-between items-center">
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Zap className="h-3 w-3" />
                    Attempts: {attempts}/{maxAttempts}
                  </Badge>
                  {gameStatus === "won" && (
                    <Badge className="bg-green-500 hover:bg-green-600">
                      <Trophy className="h-3 w-3 mr-1" />
                      Winner! +{score} pts
                    </Badge>
                  )}
                  {gameStatus === "lost" && <Badge variant="destructive">Game Over</Badge>}
                </div>

                {/* Feedback */}
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg text-center text-sm text-gray-700 min-h-[60px] flex items-center justify-center border">
                  {feedback}
                </div>

                {/* Input and Guess Button */}
                {gameStatus === "playing" && (
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      placeholder="Enter your guess (1-100)"
                      value={userGuess}
                      onChange={(e) => setUserGuess(e.target.value)}
                      onKeyPress={handleKeyPress}
                      min={1}
                      max={100}
                      className="flex-1"
                      disabled={loading}
                    />
                    <Button
                      onClick={makeGuess}
                      disabled={!userGuess.trim() || loading}
                      className="px-6 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                    >
                      {loading ? "..." : "Guess"}
                    </Button>
                  </div>
                )}
              </CardContent>

              <CardFooter className="flex gap-2">
                <Button onClick={startNewGame} className="flex-1" variant="default" disabled={loading}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  New Game
                </Button>
              </CardFooter>
            </Card>
          </div>

          {/* Stats Card */}
          <div className="space-y-6">
            <Card className="shadow-xl border-0 bg-white/80 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  Your Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-blue-50 p-3 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">{stats.totalScore}</div>
                    <div className="text-xs text-gray-600">Total Score</div>
                  </div>
                  <div className="bg-green-50 p-3 rounded-lg text-center">
                    <div className="text-2xl font-bold text-green-600">{winRate}%</div>
                    <div className="text-xs text-gray-600">Win Rate</div>
                  </div>
                  <div className="bg-purple-50 p-3 rounded-lg text-center">
                    <div className="text-2xl font-bold text-purple-600">{stats.gamesWon}</div>
                    <div className="text-xs text-gray-600">Games Won</div>
                  </div>
                  <div className="bg-yellow-50 p-3 rounded-lg text-center">
                    <div className="text-2xl font-bold text-yellow-600">{stats.bestStreak}</div>
                    <div className="text-xs text-gray-600">Best Streak</div>
                  </div>
                </div>

                <Separator />

                <div className="text-center">
                  <div className="text-sm text-gray-600">Current Streak</div>
                  <div className="text-xl font-bold text-orange-600">{stats.currentStreak}</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
