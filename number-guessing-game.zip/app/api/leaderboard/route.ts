import { NextResponse } from "next/server"

// Mock leaderboard data (in production, use a database)
const leaderboard = [
  { id: "1", name: "Alex Champion", score: 2450, gamesWon: 28, winRate: 93 },
  { id: "2", name: "Sarah Genius", score: 2180, gamesWon: 24, winRate: 89 },
  { id: "3", name: "Mike Master", score: 1950, gamesWon: 22, winRate: 85 },
  { id: "4", name: "Lisa Legend", score: 1720, gamesWon: 19, winRate: 82 },
  { id: "5", name: "Tom Tactician", score: 1580, gamesWon: 17, winRate: 78 },
]

export async function GET() {
  return NextResponse.json({
    success: true,
    leaderboard: leaderboard.sort((a, b) => b.score - a.score),
  })
}
