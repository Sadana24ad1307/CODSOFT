import { type NextRequest, NextResponse } from "next/server"

// In-memory storage (in production, use a database)
const games = new Map<
  string,
  {
    targetNumber: number
    attempts: number
    maxAttempts: number
    status: "playing" | "won" | "lost"
    minRange: number
    maxRange: number
  }
>()

const playerStats = new Map<
  string,
  {
    totalGames: number
    gamesWon: number
    totalScore: number
    bestStreak: number
    currentStreak: number
  }
>()

export async function POST(request: NextRequest) {
  try {
    const { action, gameId, guess, playerId } = await request.json()

    switch (action) {
      case "start":
        const targetNumber = Math.floor(Math.random() * 100) + 1
        const newGameId = Math.random().toString(36).substring(7)

        games.set(newGameId, {
          targetNumber,
          attempts: 0,
          maxAttempts: 7,
          status: "playing",
          minRange: 1,
          maxRange: 100,
        })

        return NextResponse.json({
          success: true,
          gameId: newGameId,
          message: "New game started! Guess a number between 1 and 100.",
          maxAttempts: 7,
        })

      case "guess":
        const game = games.get(gameId)
        if (!game) {
          return NextResponse.json({ success: false, message: "Game not found" })
        }

        if (game.status !== "playing") {
          return NextResponse.json({ success: false, message: "Game is already finished" })
        }

        const guessNumber = Number.parseInt(guess)
        if (isNaN(guessNumber) || guessNumber < 1 || guessNumber > 100) {
          return NextResponse.json({ success: false, message: "Please enter a valid number between 1 and 100" })
        }

        game.attempts++
        let message = ""
        let gameEnded = false
        let score = 0

        if (guessNumber === game.targetNumber) {
          game.status = "won"
          score = Math.max(100 - (game.attempts - 1) * 10, 10)
          message = `🎉 Congratulations! You guessed it in ${game.attempts} attempt${game.attempts === 1 ? "" : "s"}!`
          gameEnded = true

          // Update player stats
          updatePlayerStats(playerId, true, score)
        } else if (game.attempts >= game.maxAttempts) {
          game.status = "lost"
          message = `😔 Game over! The number was ${game.targetNumber}.`
          gameEnded = true

          // Update player stats
          updatePlayerStats(playerId, false, 0)
        } else {
          const remaining = game.maxAttempts - game.attempts
          if (guessNumber < game.targetNumber) {
            message = `📈 Too low! Try higher. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.`
          } else {
            message = `📉 Too high! Try lower. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.`
          }
        }

        return NextResponse.json({
          success: true,
          message,
          attempts: game.attempts,
          maxAttempts: game.maxAttempts,
          status: game.status,
          score,
          gameEnded,
        })

      case "stats":
        const stats = playerStats.get(playerId) || {
          totalGames: 0,
          gamesWon: 0,
          totalScore: 0,
          bestStreak: 0,
          currentStreak: 0,
        }

        return NextResponse.json({
          success: true,
          stats,
        })

      default:
        return NextResponse.json({ success: false, message: "Invalid action" })
    }
  } catch (error) {
    return NextResponse.json({ success: false, message: "Server error" })
  }
}

function updatePlayerStats(playerId: string, won: boolean, score: number) {
  const stats = playerStats.get(playerId) || {
    totalGames: 0,
    gamesWon: 0,
    totalScore: 0,
    bestStreak: 0,
    currentStreak: 0,
  }

  stats.totalGames++
  stats.totalScore += score

  if (won) {
    stats.gamesWon++
    stats.currentStreak++
    stats.bestStreak = Math.max(stats.bestStreak, stats.currentStreak)
  } else {
    stats.currentStreak = 0
  }

  playerStats.set(playerId, stats)
}
