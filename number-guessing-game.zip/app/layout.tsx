import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "GuessWise - Number Guessing Game",
  description:
    "Challenge your mind with the ultimate number guessing experience! Test your intuition and climb the leaderboard.",
  keywords: ["number guessing game", "puzzle", "brain game", "guessing game"],
  authors: [{ name: "GuessWise Team" }],
  openGraph: {
    title: "GuessWise - Number Guessing Game",
    description: "Challenge your mind with the ultimate number guessing experience!",
    type: "website",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
