"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { RefreshCw, Trophy, Target, Zap, TrendingUp, Medal, Award } from "lucide-react"

// Logo Component
function Logo({ size = "md", showText = true }: { size?: "sm" | "md" | "lg"; showText?: boolean }) {
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-12 w-12",
    lg: "h-16 w-16",
  }

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-3xl",
  }

  return (
    <div className="flex items-center gap-3">
      <div className="relative">
        <div
          className={`${sizeClasses[size]} bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg`}
        >
          <Target className="h-1/2 w-1/2 text-white" />
        </div>
        <div className="absolute -top-1 -right-1 bg-yellow-400 rounded-full p-1">
          <Zap className="h-3 w-3 text-yellow-800" />
        </div>
      </div>
      {showText && (
        <div className="flex flex-col">
          <h1
            className={`${textSizeClasses[size]} font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent`}
          >
            GuessWise
          </h1>
          <p className="text-xs text-gray-500 -mt-1">Number Guessing Game</p>
        </div>
      )}
    </div>
  )
}

// Leaderboard Component
function Leaderboard() {
  const leaderboard = [
    { id: "1", name: "Alex Champion", score: 2450, gamesWon: 28, winRate: 93 },
    { id: "2", name: "Sarah Genius", score: 2180, gamesWon: 24, winRate: 89 },
    { id: "3", name: "Mike Master", score: 1950, gamesWon: 22, winRate: 85 },
    { id: "4", name: "Lisa Legend", score: 1720, gamesWon: 19, winRate: 82 },
    { id: "5", name: "Tom Tactician", score: 1580, gamesWon: 17, winRate: 78 },
  ]

  const getRankIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Trophy className="h-5 w-5 text-yellow-500" />
      case 1:
        return <Medal className="h-5 w-5 text-gray-400" />
      case 2:
        return <Award className="h-5 w-5 text-amber-600" />
      default:
        return <span className="text-lg font-bold text-gray-500">#{index + 1}</span>
    }
  }

  return (
    <Card className="shadow-xl border-0 bg-white/80 backdrop-blur">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-500" />
          Leaderboard
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {leaderboard.map((player, index) => (
          <div key={player.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <div className="flex-shrink-0">{getRankIcon(index)}</div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-gray-800 truncate">{player.name}</div>
              <div className="text-sm text-gray-600">
                {player.gamesWon} wins • {player.winRate}% rate
              </div>
            </div>
            <Badge variant="secondary" className="font-bold">
              {player.score.toLocaleString()}
            </Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

// Main Game Component
export default function GuessWiseGame() {
  const [targetNumber, setTargetNumber] = useState<number>(0)
  const [userGuess, setUserGuess] = useState<string>("")
  const [attempts, setAttempts] = useState<number>(0)
  const [maxAttempts] = useState<number>(7)
  const [feedback, setFeedback] = useState<string>("")
  const [gameStatus, setGameStatus] = useState<"playing" | "won" | "lost">("playing")
  const [score, setScore] = useState<number>(0)
  const [stats, setStats] = useState({
    totalGames: 0,
    gamesWon: 0,
    totalScore: 0,
    bestStreak: 0,
    currentStreak: 0,
  })

  // Generate random number between 1 and 100
  const generateRandomNumber = () => {
    return Math.floor(Math.random() * 100) + 1
  }

  // Initialize new game
  const startNewGame = () => {
    const newTarget = generateRandomNumber()
    setTargetNumber(newTarget)
    setUserGuess("")
    setAttempts(0)
    setFeedback("🎯 I'm thinking of a number between 1 and 100. You have 7 attempts to guess it!")
    setGameStatus("playing")
    setScore(0)
  }

  // Handle guess submission
  const makeGuess = () => {
    const guess = Number.parseInt(userGuess)

    if (isNaN(guess) || guess < 1 || guess > 100) {
      setFeedback("⚠️ Please enter a valid number between 1 and 100")
      return
    }

    const newAttempts = attempts + 1
    setAttempts(newAttempts)

    if (guess === targetNumber) {
      // Player won
      setGameStatus("won")
      const roundScore = Math.max(100 - (newAttempts - 1) * 10, 10)
      setScore(roundScore)
      setFeedback(
        `🎉 Congratulations! You guessed it in ${newAttempts} attempt${newAttempts === 1 ? "" : "s"}! (+${roundScore} points)`,
      )

      // Update stats
      setStats((prev) => ({
        totalGames: prev.totalGames + 1,
        gamesWon: prev.gamesWon + 1,
        totalScore: prev.totalScore + roundScore,
        currentStreak: prev.currentStreak + 1,
        bestStreak: Math.max(prev.bestStreak, prev.currentStreak + 1),
      }))
    } else if (newAttempts >= maxAttempts) {
      // Player lost
      setGameStatus("lost")
      setFeedback(`😔 Game over! The number was ${targetNumber}. Better luck next time!`)

      // Update stats
      setStats((prev) => ({
        ...prev,
        totalGames: prev.totalGames + 1,
        currentStreak: 0,
      }))
    } else {
      // Continue playing
      const remaining = maxAttempts - newAttempts
      if (guess < targetNumber) {
        setFeedback(`📈 Too low! Try a higher number. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.`)
      } else {
        setFeedback(`📉 Too high! Try a lower number. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.`)
      }
    }

    setUserGuess("")
  }

  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && gameStatus === "playing") {
      makeGuess()
    }
  }

  // Initialize game on component mount
  useEffect(() => {
    startNewGame()
  }, [])

  const winRate = stats.totalGames > 0 ? Math.round((stats.gamesWon / stats.totalGames) * 100) : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Logo size="lg" />
          <p className="text-gray-600 mt-2 max-w-2xl mx-auto">
            Challenge your mind with the ultimate number guessing experience! Test your intuition, improve your
            strategy, and climb the leaderboard.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Main Game Area */}
          <div className="lg:col-span-3">
            <div className="grid md:grid-cols-3 gap-6">
              {/* Game Card */}
              <div className="md:col-span-2">
                <Card className="shadow-xl border-0 bg-white/90 backdrop-blur">
                  <CardHeader className="text-center">
                    <CardTitle className="text-xl font-bold text-gray-800 flex items-center justify-center gap-2">
                      <Target className="h-5 w-5 text-blue-600" />
                      Current Game
                    </CardTitle>
                    <CardDescription>Guess the number between 1 and 100</CardDescription>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    {/* Current Game Stats */}
                    <div className="flex justify-between items-center">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Zap className="h-3 w-3" />
                        Attempts: {attempts}/{maxAttempts}
                      </Badge>
                      {gameStatus === "won" && (
                        <Badge className="bg-green-500 hover:bg-green-600">
                          <Trophy className="h-3 w-3 mr-1" />
                          Winner! +{score} pts
                        </Badge>
                      )}
                      {gameStatus === "lost" && <Badge variant="destructive">Game Over</Badge>}
                    </div>

                    {/* Feedback */}
                    <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg text-center text-sm text-gray-700 min-h-[80px] flex items-center justify-center border-2 border-blue-100">
                      <div className="font-medium">{feedback}</div>
                    </div>

                    {/* Input and Guess Button */}
                    {gameStatus === "playing" && (
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          placeholder="Enter your guess (1-100)"
                          value={userGuess}
                          onChange={(e) => setUserGuess(e.target.value)}
                          onKeyPress={handleKeyPress}
                          min={1}
                          max={100}
                          className="flex-1 text-lg"
                        />
                        <Button
                          onClick={makeGuess}
                          disabled={!userGuess.trim()}
                          className="px-8 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold"
                          size="lg"
                        >
                          Guess!
                        </Button>
                      </div>
                    )}

                    {/* Game Over Actions */}
                    {gameStatus !== "playing" && (
                      <div className="flex gap-2 pt-2">
                        <Button
                          onClick={startNewGame}
                          className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-semibold"
                          size="lg"
                        >
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Play Again
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Stats Card */}
              <div>
                <Card className="shadow-xl border-0 bg-white/90 backdrop-blur">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                      Your Stats
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 gap-3">
                      <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-3 rounded-lg text-center border border-blue-200">
                        <div className="text-2xl font-bold text-blue-600">{stats.totalScore}</div>
                        <div className="text-xs text-gray-600 font-medium">Total Score</div>
                      </div>
                      <div className="bg-gradient-to-r from-green-50 to-green-100 p-3 rounded-lg text-center border border-green-200">
                        <div className="text-2xl font-bold text-green-600">{winRate}%</div>
                        <div className="text-xs text-gray-600 font-medium">Win Rate</div>
                      </div>
                      <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-3 rounded-lg text-center border border-purple-200">
                        <div className="text-2xl font-bold text-purple-600">{stats.gamesWon}</div>
                        <div className="text-xs text-gray-600 font-medium">Games Won</div>
                      </div>
                      <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 p-3 rounded-lg text-center border border-yellow-200">
                        <div className="text-2xl font-bold text-yellow-600">{stats.bestStreak}</div>
                        <div className="text-xs text-gray-600 font-medium">Best Streak</div>
                      </div>
                    </div>

                    <Separator />

                    <div className="text-center bg-gradient-to-r from-orange-50 to-red-50 p-3 rounded-lg border border-orange-200">
                      <div className="text-sm text-gray-600 font-medium">Current Streak</div>
                      <div className="text-xl font-bold text-orange-600">{stats.currentStreak}</div>
                    </div>

                    <div className="text-center text-xs text-gray-500 pt-2">
                      <div>Games Played: {stats.totalGames}</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* How to Play */}
            <Card className="mt-6 shadow-lg border-0 bg-white/80 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-lg">🎮 How to Play</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Game Rules:</h4>
                    <ul className="space-y-1">
                      <li>• Guess a number between 1 and 100</li>
                      <li>• You have 7 attempts to find it</li>
                      <li>• Get hints: "too high" or "too low"</li>
                      <li>• Win faster for more points!</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Scoring:</h4>
                    <ul className="space-y-1">
                      <li>• 1st attempt: 100 points</li>
                      <li>• 2nd attempt: 90 points</li>
                      <li>• 3rd attempt: 80 points</li>
                      <li>• Minimum: 10 points</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Leaderboard */}
          <div className="lg:col-span-1">
            <Leaderboard />
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-500 text-sm">
          <p>© 2024 GuessWise. Challenge your mind, one number at a time.</p>
        </div>
      </div>
    </div>
  )
}
