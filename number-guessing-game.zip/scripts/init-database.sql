-- Create database schema for GuessWise
CREATE TABLE IF NOT EXISTS players (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(255) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS games (
    id VARCHAR(36) PRIMARY KEY,
    player_id VARCHAR(36),
    target_number INTEGER NOT NULL,
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 7,
    status ENUM('playing', 'won', 'lost') DEFAULT 'playing',
    score INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (player_id) REFERENCES players(id)
);

CREATE TABLE IF NOT EXISTS player_stats (
    player_id VARCHAR(36) PRIMARY KEY,
    total_games INTEGER DEFAULT 0,
    games_won INTEGER DEFAULT 0,
    total_score INTEGER DEFAULT 0,
    best_streak INTEGER DEFAULT 0,
    current_streak INTEGER DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (player_id) REFERENCES players(id)
);

CREATE TABLE IF NOT EXISTS leaderboard (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    player_id VARCHAR(36),
    player_name VARCHAR(100),
    total_score INTEGER,
    games_won INTEGER,
    win_rate DECIMAL(5,2),
    rank_position INTEGER,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (player_id) REFERENCES players(id)
);

-- Insert sample leaderboard data
INSERT INTO leaderboard (player_id, player_name, total_score, games_won, win_rate, rank_position) VALUES
('sample1', 'Alex Champion', 2450, 28, 93.33, 1),
('sample2', 'Sarah Genius', 2180, 24, 88.89, 2),
('sample3', 'Mike Master', 1950, 22, 84.62, 3),
('sample4', 'Lisa Legend', 1720, 19, 82.61, 4),
('sample5', 'Tom Tactician', 1580, 17, 77.27, 5);
