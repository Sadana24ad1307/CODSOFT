"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { RefreshCw, Trophy, Target, Zap } from "lucide-react"

export default function NumberGuessingGame() {
  const [targetNumber, setTargetNumber] = useState<number>(0)
  const [userGuess, setUserGuess] = useState<string>("")
  const [attempts, setAttempts] = useState<number>(0)
  const [maxAttempts] = useState<number>(7)
  const [feedback, setFeedback] = useState<string>("")
  const [gameStatus, setGameStatus] = useState<"playing" | "won" | "lost">("playing")
  const [roundsPlayed, setRoundsPlayed] = useState<number>(0)
  const [roundsWon, setRoundsWon] = useState<number>(0)
  const [score, setScore] = useState<number>(0)
  const [minRange] = useState<number>(1)
  const [maxRange] = useState<number>(100)

  // Generate random number between min and max range
  const generateRandomNumber = () => {
    return Math.floor(Math.random() * (maxRange - minRange + 1)) + minRange
  }

  // Initialize game
  const initializeGame = () => {
    setTargetNumber(generateRandomNumber())
    setUserGuess("")
    setAttempts(0)
    setFeedback(`I'm thinking of a number between ${minRange} and ${maxRange}. You have ${maxAttempts} attempts!`)
    setGameStatus("playing")
  }

  // Start new round
  const startNewRound = () => {
    initializeGame()
    setRoundsPlayed((prev) => prev + 1)
  }

  // Reset entire game
  const resetGame = () => {
    initializeGame()
    setRoundsPlayed(0)
    setRoundsWon(0)
    setScore(0)
  }

  // Handle guess submission
  const handleGuess = () => {
    const guess = Number.parseInt(userGuess)

    if (isNaN(guess) || guess < minRange || guess > maxRange) {
      setFeedback(`Please enter a valid number between ${minRange} and ${maxRange}`)
      return
    }

    const newAttempts = attempts + 1
    setAttempts(newAttempts)

    if (guess === targetNumber) {
      setGameStatus("won")
      setRoundsWon((prev) => prev + 1)
      const roundScore = Math.max(100 - (newAttempts - 1) * 10, 10)
      setScore((prev) => prev + roundScore)
      setFeedback(
        `🎉 Congratulations! You guessed it in ${newAttempts} attempt${newAttempts === 1 ? "" : "s"}! (+${roundScore} points)`,
      )
    } else if (newAttempts >= maxAttempts) {
      setGameStatus("lost")
      setFeedback(`😔 Game over! The number was ${targetNumber}. Better luck next time!`)
    } else {
      const remainingAttempts = maxAttempts - newAttempts
      if (guess < targetNumber) {
        setFeedback(
          `📈 Too low! Try a higher number. ${remainingAttempts} attempt${remainingAttempts === 1 ? "" : "s"} remaining.`,
        )
      } else {
        setFeedback(
          `📉 Too high! Try a lower number. ${remainingAttempts} attempt${remainingAttempts === 1 ? "" : "s"} remaining.`,
        )
      }
    }

    setUserGuess("")
  }

  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && gameStatus === "playing") {
      handleGuess()
    }
  }

  // Initialize game on component mount
  useEffect(() => {
    initializeGame()
  }, [])

  const winRate = roundsPlayed > 0 ? Math.round((roundsWon / roundsPlayed) * 100) : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 flex items-center justify-center">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-800 flex items-center justify-center gap-2">
            <Target className="h-6 w-6 text-blue-600" />
            Number Guessing Game
          </CardTitle>
          <CardDescription>
            Guess the number between {minRange} and {maxRange}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Game Stats */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-blue-50 p-2 rounded-lg">
              <div className="text-lg font-bold text-blue-600">{score}</div>
              <div className="text-xs text-gray-600">Score</div>
            </div>
            <div className="bg-green-50 p-2 rounded-lg">
              <div className="text-lg font-bold text-green-600">
                {roundsWon}/{roundsPlayed}
              </div>
              <div className="text-xs text-gray-600">Won</div>
            </div>
            <div className="bg-purple-50 p-2 rounded-lg">
              <div className="text-lg font-bold text-purple-600">{winRate}%</div>
              <div className="text-xs text-gray-600">Win Rate</div>
            </div>
          </div>

          <Separator />

          {/* Current Game Info */}
          <div className="flex justify-between items-center">
            <Badge variant="outline" className="flex items-center gap-1">
              <Zap className="h-3 w-3" />
              Attempts: {attempts}/{maxAttempts}
            </Badge>
            {gameStatus === "won" && (
              <Badge className="bg-green-500 hover:bg-green-600">
                <Trophy className="h-3 w-3 mr-1" />
                Winner!
              </Badge>
            )}
            {gameStatus === "lost" && <Badge variant="destructive">Game Over</Badge>}
          </div>

          {/* Feedback */}
          <div className="bg-gray-50 p-3 rounded-lg text-center text-sm text-gray-700 min-h-[60px] flex items-center justify-center">
            {feedback}
          </div>

          {/* Input and Guess Button */}
          {gameStatus === "playing" && (
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="Enter your guess"
                value={userGuess}
                onChange={(e) => setUserGuess(e.target.value)}
                onKeyPress={handleKeyPress}
                min={minRange}
                max={maxRange}
                className="flex-1"
              />
              <Button onClick={handleGuess} disabled={!userGuess.trim()} className="px-6">
                Guess
              </Button>
            </div>
          )}
        </CardContent>

        <CardFooter className="flex gap-2">
          {gameStatus !== "playing" && (
            <Button onClick={startNewRound} className="flex-1" variant="default">
              <RefreshCw className="h-4 w-4 mr-2" />
              New Round
            </Button>
          )}
          <Button onClick={resetGame} variant="outline" className="flex-1">
            Reset Game
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
